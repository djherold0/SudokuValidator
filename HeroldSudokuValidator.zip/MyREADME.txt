To run this program, first you must navigate to the directory where HeroldSudokuValidator.jar is.

Then, enter the following command: java -jar HeroldSudokuValidator.jar <puzzleFile>.txt
where <puzzleFile>.txt is the name of the file that contains the sudoku puzzle solution.

You must enter a file name as an argument, because my program doesn't handle no arguments very well.

My program will read the solution from this file into an integer array and provide results on whether the solution is valid or not.